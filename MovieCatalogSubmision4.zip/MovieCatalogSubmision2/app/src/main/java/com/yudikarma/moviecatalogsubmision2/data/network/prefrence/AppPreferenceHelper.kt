package com.yudikarma.moviecatalogsubmision2.data.network.prefrence

import com.orhanobut.hawk.Hawk
//import com.yudikarma.moviecatalogsubmision2.di.PreferenceInfo
import javax.inject.Inject

/*
class AppPreferenceHelper @Inject constructor(@PreferenceInfo private val prefFileName:String):PreferenceHelper {
    override fun setString(key: String, value: String?) {
        Hawk.put(key, value)
    }

    override fun getString(key: String): String = Hawk.get(key, "")
}*/
