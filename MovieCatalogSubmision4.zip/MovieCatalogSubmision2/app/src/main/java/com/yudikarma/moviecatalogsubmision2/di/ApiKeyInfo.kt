package com.yudikarma.moviecatalogsubmision2.di

import javax.inject.Qualifier

@Qualifier
@Retention annotation class ApiKeyInfo
