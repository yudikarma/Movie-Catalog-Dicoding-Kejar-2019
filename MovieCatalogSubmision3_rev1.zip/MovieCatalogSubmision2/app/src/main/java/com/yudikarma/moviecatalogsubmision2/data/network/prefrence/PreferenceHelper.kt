package com.yudikarma.moviecatalogsubmision2.data.network.prefrence
/*

interface PreferenceHelper {
    fun setString(key: String, value: String?)

    fun getString(key: String) : String
}*/
